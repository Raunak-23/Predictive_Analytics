"""
Notebook Generator Script: Constructs customer_segmentation_naive_bayes.ipynb programmatically.
Contains a 7-stage machine learning pipeline for customer segmentation using Naive Bayes.
"""

import nbformat as nbf
import os

def create_notebook():
    nb = nbf.v4.new_notebook()
    nb.cells = []
    
    # Title & Metadata
    title_md = r"""# Customer Segmentation using Naive Bayes Algorithms
## End-to-End Modular Machine Learning Pipeline (7 Stages)

**Author:** Google Antigravity Agent  
**Dataset:** Customer Segmentation Dataset (`segmentation data.csv`)  
**Objective:** Discover natural customer segments via unsupervised clustering, then build, tune, evaluate, compare, and deploy modular Naive Bayes classification pipelines alongside baseline models to classify customer personas accurately.

---

### Pipeline Overview:
1. **Stage 1: Data and Library Import** - Setup environment, import `src/` modules, load raw dataset.
2. **Stage 2: Exploratory Data Analysis (EDA)** - Distributions, correlations, and K-Means + PCA customer segment discovery.
3. **Stage 3: Data Preprocessing & Modular Pipelines** - Feature engineering, train/test split, `ColumnTransformer` pipelines.
4. **Stage 4: Model Building** - Pipeline assembly for **GaussianNB**, **CategoricalNB**, **BernoulliNB**, **ComplementNB**, and 5 comparison algorithms.
5. **Stage 5: Hyperparameter Tuning** - Systematic tuning using `GridSearchCV` on pipeline parameters.
6. **Stage 6: Model Evaluation & Comparison** - Quantitative metrics table (Accuracy, Precision, Recall, F1, ROC-AUC).
7. **Stage 7: Visualization of Results & Artifact Saving** - Performance charts, confusion matrices, ROC curves, `.joblib` serialization, and inference verification.
"""
    nb.cells.append(nbf.v4.new_markdown_cell(title_md))
    
    # Stage 1
    stage1_md = r"""---
## Stage 1: Data and Library Import

We load essential scientific computing libraries (`pandas`, `numpy`, `matplotlib`, `seaborn`, `scikit-learn`) and our modular backend scripts (`src/`).
"""
    nb.cells.append(nbf.v4.new_markdown_cell(stage1_md))
    
    stage1_code = r"""import os
import sys
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Add workspace path
sys.path.append(os.getcwd())

# Import custom modular components
from src.data import load_raw_data, discover_customer_segments
from src.preprocessing import split_customer_data, create_standard_preprocessor
from src.models import build_model_pipelines, get_hyperparameter_grids
from src.evaluation import (
    compute_model_metrics, build_comparison_dataframe,
    plot_model_comparison, plot_confusion_matrices,
    plot_multiclass_roc, plot_pca_clusters
)
from src.utils import (
    save_pipeline_artifact, load_pipeline_artifact,
    save_metrics_json, predict_single_customer
)

# Global plot styling
sns.set_theme(style="whitegrid", palette="muted")
plt.rcParams["font.family"] = "sans-serif"

# Load raw customer data
df_raw = load_raw_data('segmentation data.csv')
print(f"Dataset shape: {df_raw.shape}")
df_raw.head()
"""
    nb.cells.append(nbf.v4.new_code_cell(stage1_code))
    
    # Stage 2
    stage2_md = r"""---
## Stage 2: Exploratory Data Analysis (EDA) & Customer Segment Discovery

We explore summary statistics, verify zero missing values, plot feature distributions, and discover natural customer personas using unsupervised K-Means clustering & Principal Component Analysis (PCA).
"""
    nb.cells.append(nbf.v4.new_markdown_cell(stage2_md))
    
    stage2_code = r"""# Summary Statistics
print("--- Missing Values ---")
print(df_raw.isnull().sum())
print("\n--- Summary Statistics ---")
display(df_raw.describe().T)

# Feature Distribution Plots
fig, axes = plt.subplots(2, 4, figsize=(16, 8))
features = [c for c in df_raw.columns if c != 'ID']

for idx, col in enumerate(features):
    ax = axes[idx // 4, idx % 4]
    sns.histplot(df_raw[col], kde=True, ax=ax, color='teal')
    ax.set_title(f'Distribution of {col}', fontweight='bold')
    
plt.tight_layout()
plt.show()

# Perform Unsupervised Customer Segmentation (K=4)
df_segmented, kmeans_model, scaler_model, pca_model = discover_customer_segments(df_raw, n_clusters=4)

print("\n--- Discovered Customer Segment Distributions ---")
display(df_segmented['Segment_Label'].value_counts())

# Plot Customer Segments in 2D PCA Space
plot_pca_clusters(df_segmented);
"""
    nb.cells.append(nbf.v4.new_code_cell(stage2_code))
    
    # Stage 3
    stage3_md = r"""---
## Stage 3: Data Preprocessing & Modular Pipelines

We separate the features (`Age`, `Income`, `Sex`, `Marital status`, `Education`, `Occupation`, `Settlement size`) and target (`Segment`), and perform a stratified 80/20 train/test split.
We use Scikit-Learn `ColumnTransformer` pipelines to preprocess continuous vs categorical features.
"""
    nb.cells.append(nbf.v4.new_markdown_cell(stage3_md))
    
    stage3_code = r"""# Train / Test Split
X_train, X_test, y_train, y_test = split_customer_data(df_segmented, target_col='Segment', test_size=0.2, random_state=42)

print(f"X_train shape: {X_train.shape}")
print(f"X_test shape:  {X_test.shape}")
print("\nTarget Class Distribution in Train Set:")
print(y_train.value_counts(normalize=True))
"""
    nb.cells.append(nbf.v4.new_code_cell(stage3_code))
    
    # Stage 4
    stage4_md = r"""---
## Stage 4: Model Building

We instantiate modular Scikit-Learn `Pipeline` architectures for 4 Naive Bayes variants and 5 benchmark comparison models:
1. **Gaussian Naive Bayes** (`GaussianNB`)
2. **Categorical Naive Bayes** (`CategoricalNB`)
3. **Bernoulli Naive Bayes** (`BernoulliNB`)
4. **Complement Naive Bayes** (`ComplementNB`)
5. **Logistic Regression**
6. **Random Forest**
7. **Decision Tree**
8. **Support Vector Machine (SVC)**
9. **K-Nearest Neighbors (KNN)**
"""
    nb.cells.append(nbf.v4.new_markdown_cell(stage4_md))
    
    stage4_code = r"""# Build raw model pipelines
raw_pipelines = build_model_pipelines(random_state=42)

print(f"Successfully constructed {len(raw_pipelines)} model pipelines:")
for name in raw_pipelines:
    print(f"  [+] Pipeline: {name}")
"""
    nb.cells.append(nbf.v4.new_code_cell(stage4_code))
    
    # Stage 5
    stage5_md = r"""---
## Stage 5: Hyperparameter Tuning

We execute 5-fold cross-validation hyperparameter optimization using `GridSearchCV` on pipeline parameters (such as `var_smoothing` for GaussianNB and `alpha` for discrete Naive Bayes variants).
"""
    nb.cells.append(nbf.v4.new_markdown_cell(stage5_md))
    
    stage5_code = r"""from sklearn.model_selection import GridSearchCV

param_grids = get_hyperparameter_grids()
tuned_pipelines = {}
best_params_report = {}

for name, pipeline in raw_pipelines.items():
    grid_params = param_grids.get(name, {})
    if grid_params:
        search = GridSearchCV(
            pipeline, param_grid=grid_params, cv=5, scoring='f1_weighted', n_jobs=-1
        )
        search.fit(X_train, y_train)
        tuned_pipelines[name] = search.best_estimator_
        best_params_report[name] = {
            'Best Params': str(search.best_params_),
            'Best CV F1-Score': round(search.best_score_, 4)
        }
    else:
        pipeline.fit(X_train, y_train)
        tuned_pipelines[name] = pipeline
        best_params_report[name] = {'Best Params': 'Default', 'Best CV F1-Score': 'N/A'}

df_tuning_summary = pd.DataFrame(best_params_report).T
display(df_tuning_summary)
"""
    nb.cells.append(nbf.v4.new_code_cell(stage5_code))
    
    # Stage 6
    stage6_md = r"""---
## Stage 6: Model Evaluation and Comparison

We evaluate all tuned model pipelines on the holdout test set across **Accuracy**, **Precision (Weighted)**, **Recall (Weighted)**, **F1-Score (Weighted)**, **F1-Score (Macro)**, and **ROC-AUC (Weighted OvR)**.
"""
    nb.cells.append(nbf.v4.new_markdown_cell(stage6_md))
    
    stage6_code = r"""# Compute test metrics for all models
evaluation_results = []

for name, model in tuned_pipelines.items():
    metrics = compute_model_metrics(model, X_test, y_test, model_name=name)
    evaluation_results.append(metrics)
    
df_comparison = build_comparison_dataframe(evaluation_results)
print("=== FINAL MODEL PERFORMANCE COMPARISON TABLE ===")
display(df_comparison)
"""
    nb.cells.append(nbf.v4.new_code_cell(stage6_code))
    
    # Stage 7
    stage7_md = r"""---
## Stage 7: Visualization of Results and Artifact Saving

We generate performance comparison bar charts, confusion matrix heatmaps, multiclass ROC curves, save `.joblib` model pipeline artifacts to `artifacts/`, and test production inference reload.
"""
    nb.cells.append(nbf.v4.new_markdown_cell(stage7_md))
    
    stage7_code = r"""# 1. Performance Comparison Bar Chart
fig_comp = plot_model_comparison(df_comparison)
plt.show()

# 2. Confusion Matrices for Naive Bayes Variants & Baselines
selected_models = {
    'Gaussian NB': tuned_pipelines['Gaussian Naive Bayes'],
    'Categorical NB': tuned_pipelines['Categorical Naive Bayes'],
    'Bernoulli NB': tuned_pipelines['Bernoulli Naive Bayes'],
    'Complement NB': tuned_pipelines['Complement Naive Bayes'],
    'Random Forest': tuned_pipelines['Random Forest'],
    'Logistic Regression': tuned_pipelines['Logistic Regression']
}
class_labels = ["Fewer Opp.", "Standard", "Career-Foc.", "Well-Off"]
fig_cm = plot_confusion_matrices(selected_models, X_test, y_test, class_names=class_labels)
plt.show()

# 3. Multiclass OvR ROC Curve for Gaussian Naive Bayes
gnb_model = tuned_pipelines['Gaussian Naive Bayes']
fig_roc = plot_multiclass_roc(gnb_model, X_test, y_test, model_name='Gaussian Naive Bayes', class_names=class_labels)
plt.show()

# 4. Save Artifacts
os.makedirs('artifacts', exist_ok=True)
save_pipeline_artifact(gnb_model, 'artifacts/gaussian_nb_pipeline.joblib')
save_pipeline_artifact(tuned_pipelines['Categorical Naive Bayes'], 'artifacts/categorical_nb_pipeline.joblib')

best_model_name = df_comparison.iloc[0]['Model']
best_model_pipeline = tuned_pipelines[best_model_name]
save_pipeline_artifact(best_model_pipeline, 'artifacts/best_model_pipeline.joblib')
save_metrics_json(evaluation_results, 'artifacts/model_metrics.json')

print(f"Top Model Saved: {best_model_name} -> artifacts/best_model_pipeline.joblib")

# 5. Production Inference Verification
print("\n--- Production Pipeline Reload & Test Inference ---")
reloaded_pipeline = load_pipeline_artifact('artifacts/best_model_pipeline.joblib')

sample_customer = {
    'Sex': 1,
    'Marital status': 1,
    'Age': 24,
    'Education': 1,
    'Income': 125000,
    'Occupation': 1,
    'Settlement size': 0
}

inference_result = predict_single_customer(reloaded_pipeline, sample_customer)
print(f"Input Customer Profile: {sample_customer}")
print(f"Predicted Segment:      {inference_result['Predicted_Segment_Name']} (ID: {inference_result['Predicted_Segment_ID']})")
print("Class Probabilities:")
for seg, prob in inference_result['Class_Probabilities'].items():
    print(f"  - {seg:20s}: {prob:.4f}")
"""
    nb.cells.append(nbf.v4.new_code_cell(stage7_code))
    
    # Write to notebook file
    filepath = 'customer_segmentation_naive_bayes.ipynb'
    with open(filepath, 'w', encoding='utf-8') as f:
        nbf.write(nb, f)
        
    print(f"Successfully generated Jupyter Notebook: {filepath}")

if __name__ == '__main__':
    create_notebook()
