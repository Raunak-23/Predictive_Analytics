"""
DOCX Generator Script for Customer Segmentation Benchmark Report.
Parses customer_segmentation_report.md and converts it into a beautifully styled, editable Microsoft Word (.docx) report.
"""

import os
import re
import docx
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_ALIGN_VERTICAL
from docx.oxml import OxmlElement, parse_xml
from docx.oxml.ns import nsdecls, qn

def set_cell_background(cell, fill_hex):
    """Sets cell background color in docx using hex color string."""
    shading_elm = parse_xml(f'<w:shd {nsdecls("w")} w:fill="{fill_hex}"/>')
    cell._tc.get_or_add_tcPr().append(shading_elm)

def set_cell_margins(cell, top=100, bottom=100, left=150, right=150):
    """Sets inner cell margins (padding) in dxa (1 pt = 20 dxa)."""
    tcPr = cell._tc.get_or_add_tcPr()
    tcMar = OxmlElement('w:tcMar')
    for m, val in [('top', top), ('bottom', bottom), ('left', left), ('right', right)]:
        node = OxmlElement(f'w:{m}')
        node.set(qn('w:w'), str(val))
        node.set(qn('w:type'), 'dxa')
        tcMar.append(node)
    tcPr.append(tcMar)

def create_styled_report(md_filepath: str, output_docx_filepath: str):
    """Parses markdown report and builds styled Word Document."""
    if not os.path.exists(md_filepath):
        raise FileNotFoundError(f"Markdown file not found: {md_filepath}")
        
    with open(md_filepath, 'r', encoding='utf-8') as f:
        md_text = f.read()

    doc = Document()
    
    # Page Margins (1 inch)
    sections = doc.sections
    for section in sections:
        section.top_margin = Inches(1)
        section.bottom_margin = Inches(1)
        section.left_margin = Inches(1)
        section.right_margin = Inches(1)

    # Set base Normal Style font
    style_normal = doc.styles['Normal']
    font = style_normal.font
    font.name = 'Calibri'
    font.size = Pt(11)
    font.color.rgb = RGBColor(0x26, 0x26, 0x26) # Dark Slate Gray

    lines = md_text.split('\n')
    i = 0
    in_table = False
    table_lines = []

    def flush_table(table_lines):
        if not table_lines:
            return
        
        # Parse Markdown table lines
        rows_data = []
        for line in table_lines:
            if re.match(r'^\s*\|?\s*:?-+:?\s*\|', line):
                continue # Skip alignment separator row
            cells = [c.strip() for c in line.strip().strip('|').split('|')]
            if cells and any(cells):
                rows_data.append(cells)
                
        if not rows_data:
            return

        num_cols = max(len(r) for r in rows_data)
        table = doc.add_table(rows=len(rows_data), cols=num_cols)
        table.alignment = WD_TABLE_ALIGNMENT.CENTER
        
        for row_idx, row in enumerate(rows_data):
            tr = table.rows[row_idx]
            is_header = (row_idx == 0)
            
            # Make header repeat across page breaks
            if is_header:
                trPr = tr._tr.get_or_add_trPr()
                trPr.append(OxmlElement('w:tblHeader'))

            for col_idx in range(num_cols):
                cell = tr.cells[col_idx]
                val = row[col_idx] if col_idx < len(row) else ""
                
                # Format cell text
                cell.text = ""
                p = cell.paragraphs[0]
                p.alignment = WD_ALIGN_PARAGRAPH.LEFT
                p.paragraph_format.space_before = Pt(3)
                p.paragraph_format.space_after = Pt(3)
                
                # Clean Markdown bold tags (**text**)
                parts = re.split(r'(\*\*.*?\*\*)', val)
                for part in parts:
                    if part.startswith('**') and part.endswith('**'):
                        run = p.add_run(part[2:-2])
                        run.bold = True
                    else:
                        run = p.add_run(part)
                    
                    if is_header:
                        run.bold = True
                        run.font.color.rgb = RGBColor(0xFF, 0xFF, 0xFF)
                        run.font.size = Pt(10)
                    else:
                        run.font.size = Pt(9.5)
                        
                # Shading & Padding
                if is_header:
                    set_cell_background(cell, "1F4E78") # Deep Navy Blue
                elif row_idx % 2 == 1:
                    set_cell_background(cell, "F2F4F7") # Light Zebra Gray
                else:
                    set_cell_background(cell, "FFFFFF")
                    
                set_cell_margins(cell, top=80, bottom=80, left=120, right=120)
                cell.vertical_alignment = WD_ALIGN_VERTICAL.CENTER

        doc.add_paragraph().paragraph_format.space_after = Pt(6)

    while i < len(lines):
        line = lines[i]
        stripped = line.strip()

        # Handle Markdown Tables
        if stripped.startswith('|') and stripped.endswith('|'):
            if not in_table:
                in_table = True
                table_lines = []
            table_lines.append(stripped)
            i += 1
            continue
        else:
            if in_table:
                flush_table(table_lines)
                in_table = False
                table_lines = []

        # Empty lines
        if not stripped:
            i += 1
            continue

        # Headings
        if stripped.startswith('# '):
            p = doc.add_paragraph()
            p.paragraph_format.space_before = Pt(18)
            p.paragraph_format.space_after = Pt(8)
            p.paragraph_format.keep_with_next = True
            run = p.add_run(stripped[2:])
            run.font.size = Pt(22)
            run.font.bold = True
            run.font.color.rgb = RGBColor(0x1F, 0x4E, 0x78) # Deep Navy Blue
            
        elif stripped.startswith('## '):
            p = doc.add_paragraph()
            p.paragraph_format.space_before = Pt(14)
            p.paragraph_format.space_after = Pt(6)
            p.paragraph_format.keep_with_next = True
            run = p.add_run(stripped[3:])
            run.font.size = Pt(16)
            run.font.bold = True
            run.font.color.rgb = RGBColor(0x2E, 0x75, 0xB6) # Steel Blue
            
        elif stripped.startswith('### '):
            p = doc.add_paragraph()
            p.paragraph_format.space_before = Pt(10)
            p.paragraph_format.space_after = Pt(4)
            p.paragraph_format.keep_with_next = True
            run = p.add_run(stripped[4:])
            run.font.size = Pt(13)
            run.font.bold = True
            run.font.color.rgb = RGBColor(0x1F, 0x4E, 0x78)

        elif stripped.startswith('#### '):
            p = doc.add_paragraph()
            p.paragraph_format.space_before = Pt(8)
            p.paragraph_format.space_after = Pt(3)
            p.paragraph_format.keep_with_next = True
            run = p.add_run(stripped[5:])
            run.font.size = Pt(11.5)
            run.font.bold = True
            run.font.color.rgb = RGBColor(0x59, 0x59, 0x59)

        # Horizontal Rule
        elif stripped == '---':
            p = doc.add_paragraph()
            p.paragraph_format.space_before = Pt(6)
            p.paragraph_format.space_after = Pt(6)
            run = p.add_run('―' * 55)
            run.font.color.rgb = RGBColor(0xD9, 0xD9, 0xD9)

        # Bullet lists
        elif stripped.startswith('- ') or stripped.startswith('* '):
            p = doc.add_paragraph(style='List Bullet')
            p.paragraph_format.space_before = Pt(2)
            p.paragraph_format.space_after = Pt(2)
            bullet_text = stripped[2:]
            parts = re.split(r'(\*\*.*?\*\*)', bullet_text)
            for part in parts:
                if part.startswith('**') and part.endswith('**'):
                    run = p.add_run(part[2:-2])
                    run.bold = True
                else:
                    run = p.add_run(part)

        # Code blocks (skip triple backticks or render as formatted code box)
        elif stripped.startswith('```'):
            code_lines = []
            i += 1
            while i < len(lines) and not lines[i].strip().startswith('```'):
                code_lines.append(lines[i])
                i += 1
            
            code_block_text = '\n'.join(code_lines)
            table_code = doc.add_table(rows=1, cols=1)
            table_code.alignment = WD_TABLE_ALIGNMENT.CENTER
            cell_code = table_code.cell(0, 0)
            set_cell_background(cell_code, "F2F2F2")
            set_cell_margins(cell_code, top=100, bottom=100, left=150, right=150)
            
            p_code = cell_code.paragraphs[0]
            p_code.paragraph_format.space_before = Pt(4)
            p_code.paragraph_format.space_after = Pt(4)
            run_code = p_code.add_run(code_block_text)
            run_code.font.name = 'Consolas'
            run_code.font.size = Pt(9)
            run_code.font.color.rgb = RGBColor(0x33, 0x33, 0x33)
            
            doc.add_paragraph().paragraph_format.space_after = Pt(4)

        # Standard Paragraphs
        else:
            p = doc.add_paragraph()
            p.paragraph_format.space_before = Pt(3)
            p.paragraph_format.space_after = Pt(4)
            p.paragraph_format.line_spacing = 1.15
            
            parts = re.split(r'(\*\*.*?\*\*)', stripped)
            for part in parts:
                if part.startswith('**') and part.endswith('**'):
                    run = p.add_run(part[2:-2])
                    run.bold = True
                else:
                    # Clean inline code formatting `code`
                    subparts = re.split(r'(`.*?`)', part)
                    for sub in subparts:
                        if sub.startswith('`') and sub.endswith('`'):
                            r_sub = p.add_run(sub[1:-1])
                            r_sub.font.name = 'Consolas'
                            r_sub.font.size = Pt(10)
                            r_sub.font.color.rgb = RGBColor(0xC7, 0x25, 0x4E) # Code dark red
                        else:
                            p.add_run(sub)

        i += 1

    # Flush remaining table if at end of document
    if in_table:
        flush_table(table_lines)

    # Embed Visual Figures at appropriate sections
    plot_dir = 'artifacts/plots'
    if os.path.exists(plot_dir):
        doc.add_page_break()
        p_fig = doc.add_heading("Visual Figures & Performance Artifacts", level=1)
        p_fig.paragraph_format.space_after = Pt(12)
        
        figures_to_embed = [
            ("pca_clusters.png", "Figure 1: Customer Segments Discovered in 2D PCA Space (K-Means Clustering, K=4)"),
            ("model_comparison.png", "Figure 2: Model Performance Comparison Matrix Across Classifier Algorithms"),
            ("confusion_matrices.png", "Figure 3: Heatmap of Confusion Matrices for Naive Bayes Variants & Baseline Classifiers"),
            ("gaussian_nb_roc.png", "Figure 4: Multiclass One-vs-Rest (OvR) ROC Curves for Gaussian Naive Bayes")
        ]
        
        for img_filename, caption in figures_to_embed:
            img_path = os.path.join(plot_dir, img_filename)
            if os.path.exists(img_path):
                p_img = doc.add_paragraph()
                p_img.alignment = WD_ALIGN_PARAGRAPH.CENTER
                p_img.paragraph_format.space_before = Pt(12)
                p_img.paragraph_format.space_after = Pt(4)
                
                run_img = p_img.add_run()
                run_img.add_picture(img_path, width=Inches(5.8))
                
                p_cap = doc.add_paragraph()
                p_cap.alignment = WD_ALIGN_PARAGRAPH.CENTER
                p_cap.paragraph_format.space_after = Pt(18)
                run_cap = p_cap.add_run(caption)
                run_cap.font.size = Pt(9.5)
                run_cap.font.italic = True
                run_cap.font.color.rgb = RGBColor(0x59, 0x59, 0x59)

    doc.save(output_docx_filepath)
    print(f"Successfully generated editable DOCX report: {output_docx_filepath}")

if __name__ == '__main__':
    md_file = 'customer_segmentation_report.md'
    docx_file = 'Customer_Segmentation_Benchmark_Report.docx'
    create_styled_report(md_file, docx_file)
