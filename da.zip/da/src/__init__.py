"""
Customer Segmentation Machine Learning Package
"""
__version__ = "1.0.0"
